open M

(* exp environment : var -> exp *)
module EEnv = struct
  type t = var -> exp
  let empty = fun _ -> raise (Failure "Exp Env is empty")
  let extend (x,t) eenv = fun y -> if x = y then t else (eenv y)
  let find eenv x = eenv x
end

let expand: exp -> exp 
= fun exp -> raise (Failure "NotImplemented")
  (* let rec replace exp eenv =
    match exp with
    | VAR x -> 

    | ADD of exp * exp
    | SUB of exp * exp
    | MUL of exp * exp
    | DIV of exp * exp
    | ISZERO of exp
    | IF of exp * exp * exp
    | LET of var * exp * exp
    | LETREC of var * var * exp * exp
    | PROC of var * exp
    | CALL of exp * exp
    in

  match exp with
  | LET(f, e1, e2) -> 
    let eenv = EEnv.extend (f,e1) EEnv.empty in
    (match e2 with
    | VAR x ->
      if f=x then e1
      else e2
    | ADD (e1, e2) -> ADD (replace e1 eenv, replace e2 eenv)
    | SUB (e1, e2)
    | MUL (e1, e2)
    | DIV (e1, e2)
    | ISZERO e
    | IF (e1, e2, e3)
    | LET (x, e1, e2)
    | LETREC (f, x, e1, e2)
    | PROC (x, e)
    | CALL (e1, e2)
    )
  | _ -> exp *)

    (* let eenv = EEnv.extend (f,e1) EEnv.empty in *)

  (* raise (Failure "NotImplemented") *)

(* typeof: Do not modify this function *)
let typeof : exp -> typ 
=fun exp -> 
	let exp' = expand exp in 
	M.typeof exp'  
