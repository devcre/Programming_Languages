let f = proc (x) (x) in if (f true) then 1 else ((f f) 2)
