let f = proc (x) (1) in (f 1) + (f true)
