type program = exp
and exp =
  	| SKIP
	| TRUE
	| FALSE
	| CONST of int
  	| VAR of var
  	| ADD of exp * exp
  	| SUB of exp * exp
  	| MUL of exp * exp
  	| DIV of exp * exp
	| LE of exp * exp
	| EQ of exp * exp
	| NOT of exp 
 	| IF of exp * exp * exp
	| WHILE of exp * exp 
	| LET of var * exp * exp
	| PROC of var list * exp 
	| CALLV of exp * exp list 
	| CALLR of exp * var list
	| ASSIGN of var * exp 
	| RECORD of (var * exp) list 
	| FIELD of exp * var
	| ASSIGNF of exp * var * exp 
  	| READ of var
	| PRINT of exp 
  	| SEQ of exp * exp
  	| BEGIN of exp
and var = string

type value = 
    Int of int
  | Bool of bool
  | Unit
  | Procedure of var list * exp * env
  | Record of record
  | Loc of loc
and loc = int 
and env = (var * loc) list
and mem = (loc * value) list
and record = (var * loc) list

(* conversion of value to string *)
let value2str v =
  match v with
  | Int n -> string_of_int n
  | Bool b -> string_of_bool b
  | Unit -> "."  
  | Procedure (params,e,env) -> "Procedure "
  | Record record -> "Record "
  | Loc l -> "Loc "^(string_of_int l)

(* environment *)
let empty_env = []
let extend_env (x,v) e = (x,v)::e
let rec apply_env e x = 
  match e with
  | [] -> raise (Failure (x ^ " is unbound in Env"))
  | (y,v)::tl -> if x = y then v else apply_env tl x

(* memory *)
let empty_mem = [] 
let extend_mem (l,v) m = (l,v)::(List.filter (fun (l',_) -> l != l') m)
let rec apply_mem m l = 
  match m with
  | [] -> raise (Failure ("Location " ^ string_of_int (l) ^ " is unbound in Mem"))
  | (y,v)::tl -> if l = y then v else apply_mem tl l

let counter = ref 0
let new_location () = counter:=!counter+1; (!counter)

(* conversion of env to string *)
let string_of_env env = 
	List.fold_left (fun str (x,l) -> Printf.sprintf "%s\n%s -> %d" str x l) "" env  
(* conversion of mem to string *)
let string_of_mem mem = 
	List.fold_left (fun str (l,v) -> Printf.sprintf "%s\n%d -> %s" str l (value2str v)) "" mem 		
		
exception NotImplemented
exception UndefinedSemantics
(* if the following variable is set true, gc will work (otherwise, gc simply returns a given memory). *)
let remove_garbage = ref false 

let gc: env * mem -> mem
= fun (env, mem) ->
	if (not !remove_garbage) then mem 
	else
		let rec apply_r tup_list result =
			(match tup_list with
			| (v, loc)::tl -> 
				let pt_l = apply_mem mem loc in
				if List.mem loc result then
					(match pt_l with
					| Loc j_loc ->
						if List.mem j_loc result then apply_r tl result
						else apply_r ((v,j_loc)::tl) (j_loc::result)
					| Record rlist ->
						apply_r (rlist@tl) result
					| Procedure (_, _, env') ->
						apply_r (env'@tl) result
					| _ -> apply_r tl result
					)
				else
				(match pt_l with
				| Loc j_loc ->
					if List.mem j_loc result then apply_r tl (loc::result)
					else apply_r ((v,j_loc)::tl) (loc::j_loc::result)
				| Record rlist ->
					apply_r (rlist@tl) (loc::result)
				| Procedure (_, _, env') ->
					apply_r (env'@tl) (loc::result)
				| _ -> apply_r tl (loc::result)
				)
			| _ -> result
			) in

		let f_reach = apply_r env [] in

		let rec make_mem f_reach =
			(match f_reach with
			| [] -> []
			| hd::tl -> 
				let l = apply_mem mem hd in
				(hd,l)::(make_mem tl)
			) in
		
		make_mem f_reach

let rec eval : program -> env -> mem -> (value * mem)
=fun pgm env mem ->
  match pgm with
  	| READ x -> (Unit, extend_mem (apply_env env x, Int (read_int())) mem) (* Do not modify *)
	| PRINT e ->
		let v, mem' = eval e env mem in
		let _ = print_endline (value2str v) in
		(v, gc(env,mem')) (* Do not modify *) 
	| SKIP -> (Unit, mem)
	| TRUE -> (Bool true, mem)
	| FALSE -> (Bool false, mem)
	| CONST n -> (Int n, mem)
	| VAR x -> (apply_mem mem (apply_env env x), mem)
	| ADD (e1, e2) ->
		let (v1, mem1) = eval e1 env mem in
        let (v2, mem2) = eval e2 env mem1 in
        (match v1, v2 with
        | Int n1, Int n2 -> (Int (n1 + n2), mem2)
        | _ -> raise UndefinedSemantics)
	| SUB (e1, e2) ->
		let (v1, mem1) = eval e1 env mem in
        let (v2, mem2) = eval e2 env mem1 in
        (match v1, v2 with
        | Int n1, Int n2 -> (Int (n1 - n2), mem2)
        | _ -> raise UndefinedSemantics)
    | MUL (e1, e2) ->
		let (v1, mem1) = eval e1 env mem in
        let (v2, mem2) = eval e2 env mem1 in
        (match v1, v2 with
        | Int n1, Int n2 -> (Int (n1 * n2), mem2)
        | _ -> raise UndefinedSemantics)
    | DIV (e1, e2) ->
		let (v1, mem1) = eval e1 env mem in
        let (v2, mem2) = eval e2 env mem1 in
        (match v1, v2 with
        | Int n1, Int n2 -> (Int (n1 / n2), mem2)
        | _ -> raise UndefinedSemantics)
	| LE (e1, e2) ->
		let (v1, mem1) = eval e1 env mem in
        let (v2, mem2) = eval e2 env mem1 in
		(match v1, v2 with
		| Int n1, Int n2 -> if n1 <= n2 then (Bool true, mem2) else (Bool false, mem2)
		| _ -> raise UndefinedSemantics)
	| EQ (e1, e2) ->
		let (v1, mem1) = eval e1 env mem in
        let (v2, mem2) = eval e2 env mem1 in
		if v1 = v2 then (Bool true, mem2) else (Bool false, mem2)
	| NOT e ->
		let (v, mem1) = eval e env mem in
		(match v with
		| Bool b -> (Bool (not b), mem1)
		| _ -> raise UndefinedSemantics)
	| IF (e1, e2, e3) ->
		let (expre, mem1) = eval e1 env mem in
        (match expre with
        | Bool true -> eval e2 env mem1
        | Bool false -> eval e3 env mem1
        | _ -> raise UndefinedSemantics)
	| WHILE (e1, e2) ->
		let (expre, mem1) = eval e1 env mem in
		(match expre with
		| Bool false -> (Unit, mem1)
		| Bool true -> 
			let (_, mem2) = eval e2 env mem1 in
			let (v2, mem3) = eval (WHILE (e1, e2)) env mem2 in
			(v2, mem3)
		| _ -> raise UndefinedSemantics)
	| LET (x, e1, e2) ->
		let (v1, mem1) = eval e1 env mem in
		let l = new_location() in
        let (v, mem2) = eval e2 (extend_env (x, l) env) (extend_mem (l, v1) mem1) in
        (v, mem2)
	| PROC (x, e) -> (Procedure (x, e, env), mem) (* x: list *)
	| CALLV (e, eparams) ->
		let rec recparams ep xp env mem =
			(match ep, xp with
			| ehd::etl, xhd::xtl -> 
				let (value, mem') = (eval ehd env mem) in
				(value, xhd)::(recparams etl xtl env mem')
			| [], [] -> []
			| _, _ -> raise UndefinedSemantics ) in

		let rec final_v list env mem expre =
			(match list with
			| (v, x)::remains ->
				let l = new_location() in
				final_v remains (extend_env (x, l) env) (extend_mem (l, v) mem) expre
			| [] -> eval expre env mem) in

		let (don, mem1) = eval e env mem in
		(match don with
		| Procedure(xparams, expre, env') -> 
			let vxparams = recparams eparams xparams env mem in
			final_v vxparams env' mem1 expre
		| _ -> raise UndefinedSemantics)

	| CALLR (e, yparams) ->
		let rec final_v xp input_yp rho' mem expre =
			(match xp, input_yp with
			| xh::xt, yh::yt -> 
				final_v xt yt (extend_env (xh, (apply_env env yh)) rho') mem expre
			| [], [] -> eval expre rho' mem
			| _, _ -> raise UndefinedSemantics) in

		let (don, mem1) = eval e env mem in
		(match don with
		| Procedure(xparams, e', env') -> final_v xparams yparams env' mem1 e'
		| _ -> raise UndefinedSemantics)
	| ASSIGN (x, e) ->
		let (v, mem1) = eval e env mem in
        let rec finderase l value mem =
        	(match mem with
            | [] -> raise UndefinedSemantics
            | (y,va)::tl -> if y = l then (l,value)::tl else (y,va)::(finderase l value tl)) in
		(v, finderase (apply_env env x) v mem)
		(* (match Loc (apply_env env x) with
		| Loc l -> (v, finderase l v mem)
		| _ -> raise UndefinedSemantics) *)
	| RECORD tup_list ->
		let record_list = [] in
		let rec make_record t_l rd mem =
			(match t_l with
			| [] -> (Record rd, mem)
			| (var, loc)::tl -> 
				let (v, mem1) = eval loc env mem in
				let l = new_location() in
				make_record tl ([(var,l)]@rd) (extend_mem (l, v) mem1)) in
		if tup_list = [] then (Unit, mem)
		else 
			let (record, memory) = (make_record tup_list record_list mem) in
			(record, memory)
	| FIELD (exp, var) ->
		let (r, mem1) = eval exp env mem in
		(match r with
			| Record r -> 
				let l' = apply_env r var in
				((apply_mem mem1 l'), mem1)
			| _ -> raise UndefinedSemantics
		)
	| ASSIGNF (expre1, variable, expre2) ->
		let (r, mem1) = eval expre1 env mem in
		let (new_v, mem2) = eval expre2 env mem1 in

		(match r with
		| Record r' -> 
			let wanted_var = apply_env r' variable in
			(new_v, extend_mem (wanted_var, new_v) mem2)
		| _ -> raise UndefinedSemantics)

  	| SEQ (e1, e2) ->
		let (v1, mem1) = eval e1 env mem in
		let (v2, mem2) = eval e2 env mem1 in
		(v2, mem2)
  	| BEGIN e ->
		let (ans, mem1) = eval e env mem in
		(ans, mem1)

let run : program -> bool -> bool -> unit 
= fun pgm with_gc print_mem_size ->
	let _ = remove_garbage := with_gc in 
	let mem = snd (eval pgm empty_env empty_mem) in   
	if (print_mem_size) then 
		print_endline (Printf.sprintf "Final mem size: %d" (List.length mem))