let f := proc (x) (x + 1) in
g(1)

