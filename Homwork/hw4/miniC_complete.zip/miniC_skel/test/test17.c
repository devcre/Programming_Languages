if ({} = skip) { print (11) } else { print (22) }
