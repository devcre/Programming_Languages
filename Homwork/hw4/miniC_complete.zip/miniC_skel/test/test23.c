let f := proc (x) (x + 1) in
let f := 2 in
print (f + f)

