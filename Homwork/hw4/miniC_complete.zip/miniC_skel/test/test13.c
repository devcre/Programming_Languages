let f := proc (x, y, z) ((x + y) * z) in
print (f (2, 3, 5))
