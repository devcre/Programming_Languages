 let y:=1 in
   let x:=1 in
     let x:=2 in
      (y:=x+1);
    ;
    (y:=y+x);
    print (y)
   

