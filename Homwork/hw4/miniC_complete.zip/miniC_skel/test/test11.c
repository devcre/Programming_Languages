let x := {fst := true, snd := 3 } in
(x.fst := 7);
print (x.fst)
