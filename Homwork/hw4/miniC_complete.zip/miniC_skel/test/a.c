let x := {fst := true, snd := 3 } in
print(x.snd)