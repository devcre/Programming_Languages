if (3 <= 2) {
  skip
}
else {
        if (skip = 3) { x }
        else { print (25) }
}

