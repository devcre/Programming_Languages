 let x := 0 in
   let y := 0 in
     let i := 1 in
       let r := 1 in
          read(x);
	  read(y);
	  while ((i<=y)){
            (r := r*x);
	    (i := i+1)
	  };
	  print(r)
      
    
  

    
    

