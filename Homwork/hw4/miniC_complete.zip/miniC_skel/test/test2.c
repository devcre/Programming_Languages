 let x := 1 in
   let y := 2 in
    if (x = y) {
        print (1)
    } else {
        print (2)
    }
  

