 let x := 0 in
  while (x <= 9) {
    (x := x + 1);
    print (x)
  }
