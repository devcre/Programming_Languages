let x := {} in
let y := {} in
let z := {} in
if ((x := 1) + (y := 2) + (z := 3) = 6) { print (x + y + z) } else { skip }
