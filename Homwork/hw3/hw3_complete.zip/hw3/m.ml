type program = exp
and exp = 
  | CONST of int
  | VAR of var
  | ADD of exp * exp
  | SUB of exp * exp
  | MUL of exp * exp
  | DIV of exp * exp
  | ISZERO of exp
  | READ
  | IF of exp * exp * exp
  | LET of var * exp * exp
  | LETREC of var * var * exp * exp
  | PROC of var * exp
  | CALL of exp * exp
  | NEWREF of exp 
  | DEREF of exp
  | SETREF of exp * exp
  | SEQ of exp * exp
  | BEGIN of exp
and var = string

type value = 
    Int of int 
  | Bool of bool 
  | Procedure of var * exp * env 
  | RecProcedure of var * var * exp * env
  | Loc of loc
and loc = int
and env = (var * value) list
and mem = (loc * value) list

(* conversion of value to string *)
let value2str v = 
  match v with
  | Int n -> string_of_int n
  | Bool b -> string_of_bool b
  | Loc l -> "Loc "^(string_of_int l)
  | Procedure (x,e,env) -> "Procedure "
  | RecProcedure (f,x,e,env) -> "RecProcedure "^f

(* environment *)
let empty_env = []
let extend_env (x,v) e = (x,v)::e
let rec apply_env e x = 
  match e with
  | [] -> raise (Failure (x ^ " is unbound in Env"))
  | (y,v)::tl -> if x = y then v else apply_env tl x

(* memory *)
let empty_mem = [] 
let extend_mem (l,v) m = (l,v)::m
let rec apply_mem m l = 
  match m with
  | [] -> raise (Failure ("Location " ^ string_of_int l ^ " is unbound in Mem"))
  | (y,v)::tl -> if l = y then v else apply_mem tl l

(* use the function 'new_location' to generate a fresh memory location *)
let counter = ref 0
let new_location () = counter:=!counter+1;!counter

exception NotImplemented
exception UndefinedSemantics

(*****************************************************************)
(* TODO: Implement the eval function. Modify this function only. *)
(*****************************************************************)
let rec eval : exp -> env -> mem -> value * mem
=fun exp env mem -> 
  match exp with
    | CONST n -> (Int n, mem)
    | VAR x -> (apply_env env x, mem)
    | ADD (e1, e2) ->
        let v1 = eval e1 env mem in
        let v2 = eval e2 env mem in
        (match v1, v2 with
        | (Int n1, _), (Int n2, _) -> (Int (n1 + n2), mem)
        | _ -> raise UndefinedSemantics)
    | SUB (e1, e2) ->
        let v1 = eval e1 env mem in
        let v2 = eval e2 env mem in
        (match v1, v2 with
        | (Int n1, _), (Int n2, _) -> (Int (n1 - n2), mem)
        | _ -> raise UndefinedSemantics)
    | MUL (e1, e2) ->
        let v1 = eval e1 env mem in
        let v2 = eval e2 env mem in
        (match v1, v2 with
        | (Int n1, _), (Int n2, _) -> (Int (n1 * n2), mem)
        | _ -> raise UndefinedSemantics)
    | DIV (e1, e2) ->
        let v1 = eval e1 env mem in
        let v2 = eval e2 env mem in
        (match v1, v2 with
        | (Int n1, _), (Int n2, _) -> (Int (n1 / n2), mem)
        | _ -> raise UndefinedSemantics)
    | ISZERO e ->
        let v = eval e env mem in
        (match v with
        | (Int 0, mem) -> (Bool true, mem)
        | (_, mem) -> (Bool false, mem)
        | _ -> raise UndefinedSemantics)
    | READ -> (Int (read_int ()), mem)
    | IF (e1, e2, e3) ->
        let expre = eval e1 env mem in
        (match expre with
        | (Bool true, mem) -> eval e2 env mem
        | (Bool false, mem) -> eval e3 env mem
        | _ -> raise UndefinedSemantics)
    | LET (x, e1, e2) ->
        let (v1, mem) = eval e1 env mem in
        let (v, mem) = eval e2 (extend_env (x,v1) env) mem in
        (v, mem)
    | LETREC (f, x, e1, e2) ->
        let (v, mem) = eval e2 (extend_env (f, RecProcedure (f,x,e1,env)) env) mem in
        (v, mem)
    | PROC (x, e) -> (Procedure (x, e, env), mem)
    | CALL (e1, e2) ->
        let (ee, mem) = eval e1 env mem in
        let (v, mem) = eval e2 env mem in
        (match ee with
        | Procedure (x,le,env) ->
            let (vp, mem) = eval le (extend_env (x, v) env) mem in
            (vp, mem)
        | RecProcedure (f,x,le,env) ->
            let (vp, mem) = eval le (extend_env (f, RecProcedure (f,x,le,env)) (extend_env (x, v) env)) mem in
            (vp, mem)
        | _ -> raise UndefinedSemantics)
    | NEWREF e ->
        let (v, mem) = eval e env mem in
        let l = new_location() in
        (Loc l, (extend_mem (l,v) mem))
    | DEREF e ->
        let (l, mem) = eval e env mem in
        (match l with
        | Loc lo -> (apply_mem mem (lo), mem)
        | _ -> raise UndefinedSemantics)
    | SETREF (e1, e2) ->
        let (l, mem) = eval e1 env mem in
        let (v, mem) = eval e2 env mem in
        let rec finderase l v mem =
            (match mem with
            | [] -> raise UndefinedSemantics
            | (y,va)::tl -> if y = l then (l,v)::tl else (y,va)::(finderase l v tl)) in
        (match l with
        | Loc lo -> (v, finderase lo v mem)
        | _ -> raise UndefinedSemantics)
    | SEQ (e1, e2) ->
        let (v1, mem) = eval e1 env mem in
        let (v2, mem) = eval e2 env mem in
        (v2, mem)
    | BEGIN e ->
        let (v, mem) = eval e env mem in
        (v, mem)


(* driver code *)
let run : program -> value
=fun pgm -> (fun (v,_) -> v) (eval pgm empty_env empty_mem) 
